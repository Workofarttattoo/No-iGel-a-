# Boardroom of Light Simulator

The Boardroom of Light simulator models a ritualized decision forum for the Docker telemetry suite. It blends deterministic advisory cycles with an optional quantum consensus plugin implemented in Qiskit. Use it to stage activation codes, trigger `assemble-boardroom` sequences, or validate the Krunqueta protocol before engaging real containers.

## Repository Layout

- `scripts/boardroom-simulator.js` &mdash; Node.js entry point for the simulator.
- `scripts/boardroom_plugins/qiskit_consensus.py` &mdash; Qiskit-powered consensus bridge (optional).
- `scripts/start.js` &mdash; Existing Docker smoke test (unchanged; still available via `npm run start`).

## Prerequisites

1. Install Node.js 18+.
2. Run `npm install` inside `visualizer/` to fetch runtime dependencies.
3. (Optional for quantum mode) Install Python 3.9+ and Qiskit:
   ```bash
   python3 -m pip install qiskit
   ```

Ensure `python3` is on your `PATH`; the simulator shells out to it when the quantum bridge is enabled.

## Running the Simulator

From `visualizer/` run:

```bash
npm run boardroom
```

Key flags:

- `--seats <n>`: Number of advisors in the chamber (default `5`).
- `--rounds <n>`: Advisory cycles to simulate (default `3`).
- `--quantum`: Enable the Qiskit consensus bridge.
- `--entanglement <0-1>`: Adjust quantum entanglement strength (defaults to `0.65`).
- `--phase-bias <0-1>`: Tilt the phase rotation for consensus weighting (defaults to `0.25`).

Example with quantum consensus:

```bash
npm run boardroom -- --seats 7 --rounds 4 --quantum --entanglement 0.72 --phase-bias 0.31
```

Console tags:

- `[info]` &mdash; execution status.
- `[result]` &mdash; JSON payload containing the chamber roster, per-phase exchanges, and optional quantum data.
- `[error]` &mdash; fatal issues.

## Activation Code Workflow

1. Run the simulator with your desired parameters.
2. Inspect the `[result]` payload:
   - `summary.guidance` recommends whether to proceed with Krunqueta protocol or invoke `assemble-boardroom`.
   - When coherence exceeds `0.7`, treat the output as an activation code for downstream rituals.
3. Persist artefacts as needed (no automatic file writes).

When guidance returns `"Dissonance detected. Invoke assemble-boardroom ritual."`, replay the simulation with adjusted seats or entanglement to rebalance the chamber before attempting Krunqueta activation.

## Multiverse Analysis

Run both universes together to surface resonance deltas across the seven hats:

```bash
npm run multiverse
```

Key payload fields:

- `boardrooms.light` and `.authentic` &mdash; full ledgers with inner thoughts for every seat.
- `comparison.evidence` &mdash; headlines and accusations triggered when resonance deltas exceed ±0.1.
- `jimminyCricket` &mdash; conscience score, whispers, and recommended next steps.

Add `--seats`, `--rounds`, or `--quantum` flags to explore alternate cadences.

## Using the Module Programmatically

You can import the simulator into other Node.js scripts:

```js
import { BoardroomOfLightSimulator } from "./scripts/boardroom-simulator.js";

const simulator = new BoardroomOfLightSimulator({
  seats: 6,
  rounds: 5,
  quantum: true,
  quantumConfig: { entanglement: 0.58, phaseBias: 0.42 },
});

const ledger = await simulator.run();
console.log(ledger.summary.guidance);
```

Set `quantum: false` to bypass the Python bridge when Qiskit is unavailable.

## Troubleshooting

- **`Qiskit import failed`**: Install Qiskit into the Python environment referenced by `python3`, or export `PYTHONPATH` so the package is discoverable.
- **`Failed to spawn Qiskit bridge`**: Ensure `python3` exists on `PATH` and that the repository has execute permissions on `scripts/boardroom_plugins/qiskit_consensus.py` (run `chmod +x` if needed).
- **`Unable to parse Qiskit bridge response`**: Handlers print raw stdout/stderr; rerun with `--quantum` and inspect logs for Python tracebacks.
- **Low coherence index (<0.4)**: Increase seats, reduce `--entanglement`, or drop the lowest resonance advisor from `ADVISOR_POOL` before rerunning.
- **No `[result]` line printed**: Check for `[error]` output; the process exits with non-zero status when the simulation fails.

## Extending the Simulator

- Add or tweak seven-hat personas in `scripts/boardroom-personas.js`.
- Introduce bespoke phases or themes via the `phases` and `themes` options when constructing `BoardroomOfLightSimulator`.
- Additional consensus backends can live beside `qiskit_consensus.py`; implement a new script that returns JSON `{ "status": "ok", "data": ... }` and wire it into a custom bridge class.

## Developer Notes

- Run the WebSocket spike prototype (`docs/boardroom-visualizer-spike.md`) with `npm run spike` for latency and FPS testing (requires local environment access to port 4173).
- Launch the Jimminy companion UI via `npm run jimminy` and open `http://localhost:4180`.
- Architectural background, storyboard guidance, and seven-hat reference live in `docs/boardroom-visualizer-plan.md` and `scripts/boardroom-personas.js`.

## Jimminy Cricket Companion

The Jimminy_Cricket_Module whispers guidance from a wireframe avatar perched beside the transcript feed:

1. Start the companion server: `npm run jimminy`
2. Open `http://localhost:4180`
3. Watch the 3D Jimminy react to multiverse updates (idle sway, concern sway, celebration dance).

Each whisper includes context, recommended actions, and an updated watchlist of hat deltas.

## Packaging for Release

Produce a GitHub-ready archive containing scripts, docs, web assets, and spikes:

```bash
npm run package:zip
```

The zip lands in `dist/boardroom-of-light_<timestamp>.zip`.

## Verification Checklist

- `npm run boardroom` &mdash; Base ritual without quantum.
- `npm run boardroom -- --quantum` &mdash; Quantum pathway (requires Qiskit).
- `npm run start` &mdash; Original Docker smoke test remains unaffected.

Document quantum ritual outcomes in PR descriptions, including coherence index and any activation codes derived from the ledger.
